import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from './store/authStore';

// Components
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Studio from './components/Studio';
import Classes from './components/Classes';
import Testimonials from './components/Testimonials';
import Products from './components/Products';
import Contact from './components/Contact';
import Footer from './components/Footer';
import StorePage from './components/Store/StorePage';
import AdminPanel from './components/Admin/AdminPanel';
import AuthModal from './components/Auth/AuthModal';
import CartSidebar from './components/Cart/CartSidebar';

// Home Page Component
const HomePage = () => (
  <>
    <Hero />
    <About />
    <Studio />
    <Classes />
    <Testimonials />
    <Products />
    <Contact />
  </>
);

function App() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const { initialize } = useAuthStore();

  useEffect(() => {
    initialize();
  }, [initialize]);

  return (
    <Router>
      <div className="min-h-screen" dir="rtl">
        <Header onAuthClick={() => setIsAuthModalOpen(true)} />
        
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/store" element={<StorePage />} />
          <Route path="/admin" element={<AdminPanel />} />
        </Routes>
        
        <Footer />
        
        {/* Modals and Sidebars */}
        <AuthModal 
          isOpen={isAuthModalOpen} 
          onClose={() => setIsAuthModalOpen(false)} 
        />
        <CartSidebar 
          onAuthRequired={() => setIsAuthModalOpen(true)} 
        />
        
        {/* Toast Notifications */}
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 3000,
            style: {
              background: '#374151',
              color: '#fff',
              fontFamily: 'Heebo, sans-serif',
            },
          }}
        />
      </div>
    </Router>
  );
}

export default App;