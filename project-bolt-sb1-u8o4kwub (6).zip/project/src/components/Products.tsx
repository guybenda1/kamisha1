import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const Products = () => {
  const featuredProducts = [
    {
      title: "צמיד מדיטציה",
      description: "צמיד עשוי אבנים טבעיות לחיזוק המיקוד והשלווה",
      price: "₪180",
      image: "https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      category: "תכשיטים"
    },
    {
      title: "שרשרת צ'אקרות",
      description: "שרשרת מיוחדת לאיזון האנרגיות עם אבני חן טבעיות",
      price: "₪320",
      image: "https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      category: "תכשיטים"
    },
    {
      title: "מחצלת יוגה פרימיום",
      description: "מחצלת יוגה איכותית עם אחיזה מעולה ועמידות לאורך זמן",
      price: "₪250",
      image: "https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      category: "ציוד יוגה"
    },
    {
      title: "ספר מדיטציה",
      description: "מדריך מקיף למדיטציה יומית ותרגולי נשימה",
      price: "₪120",
      image: "https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      category: "ספרים"
    }
  ];

  return (
    <section id="products" className="py-20 bg-warm-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-sage-800 mb-4 font-hebrew">
            קולקציית הסטודיו
          </h2>
          <p className="text-lg text-sage-600 max-w-2xl mx-auto font-hebrew-light">
            מוצרים נבחרים לתמיכה בתרגול היוגה והמדיטציה שלכם
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {featuredProducts.map((product, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full">
                  <span className="text-xs font-hebrew-light text-sage-600">{product.category}</span>
                </div>
              </div>
              
              <div className="p-6 text-right">
                <h3 className="text-lg font-bold text-sage-800 mb-2 font-hebrew">
                  {product.title}
                </h3>
                
                <p className="text-sage-600 text-sm mb-4 font-hebrew-light leading-relaxed">
                  {product.description}
                </p>
                
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-sage-800 font-hebrew">
                    {product.price}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <Link
            to="/store"
            className="inline-flex items-center bg-sage-600 hover:bg-sage-700 text-white px-8 py-4 rounded-lg font-hebrew font-medium transition-colors duration-300 transform hover:scale-105 space-x-2 rtl:space-x-reverse"
          >
            <span>צפה בכל המוצרים</span>
            <ArrowLeft className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Products;